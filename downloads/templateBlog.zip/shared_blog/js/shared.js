/*!
 * ScriptName: shared.js
 * Version: 1.6
 *
 * Project: FC-Blog
 *
 * FoodConnection
 * http://foodconnection.jp/
 * http://foodconnection.vn/
 *
 */

$(document).ready(function() {
});